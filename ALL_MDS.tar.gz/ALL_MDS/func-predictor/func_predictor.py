
import sys, os, re, math, random, operator, pickle
import predictor as pr
import cwgutils

def parseInputs(inputfile):
    fileData = cwgutils.readLinesAndSplit(inputfile, ',')
    QRS = []
    for line in fileData:
        if list(line[0])[0] != '#':
            if len(line) < 4:
                print("<ProjectName>,<Model-Loc>,<Cache-Loc>,<TestData-Matrix>")
                exit(0)
            if len(line) == 4:
                QRS.append((line[0], line[1], line[2], line[3]))
    return QRS

def initiatePrediction(projName, modelLoc, cacheLoc, tdatafile):
    pr.test_set(projName, modelLoc, cacheLoc, tdatafile)

if __name__=="__main__":
    script, inputfile = sys.argv
    Q = parseInputs(inputfile)
    for query in Q:
        print("\n\n\n#############################################\nRunning prediction For: ", query[0],"\t\t\n#############################################\n\n\n")
        #try:
        if True:
            initiatePrediction(query[0], query[1], query[2], query[3])
        #except:
        #    raise IOError
