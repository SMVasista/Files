
import sys, os, re, math, random, operator, pickle, copy
import numpy as NP
NP.seterr(divide='ignore', invalid='ignore')
import cwgutils
import subprocess
import shlex
#Datafile format
#features : rows
#samples : columns
#outcome in row-name "outcome"

#Global
#version = 'LC_ONCO_V17.3.3'
cwd = os.getcwd()

def marginalize(value):
    if -0.05 < float(value) < 0.05:
        return 'COF'
    elif -0.15 < float(value) < -0.05:
        return 'minLOF'
    elif float(value) < -0.15:
        return 'LOF'
    elif 0.05 < float(value) < 0.25:
        return 'minGOF'
    elif float(value) > 0.25:
        return 'GOF'

def readCsv(projName, cacheLoc, datafile):
    H = {}
    Y = {}
    y = 0
    features = cwgutils.readLinesAndSplit(datafile, ',')
    queryNames = copy.deepcopy(features[0])
    queryNames.pop(0)

    try:
        with open(os.path.join(cacheLoc, projName)+'.ma.cache', 'rb') as f:
            drugCacheData = pickle.load(f)
    except:
        print("Moving-Average cache for bio-markers not found. Results may not be accurate...")
        drugCacheData = {}

    for i in range(1, len(features)):
        key, value = cwgutils.reHeadArray(features[i])

        if key not in drugCacheData:
            drugCacheData[key] = {'std' : 1.0, 'avg': 0.0}

        value = cwgutils.mapToFloat(value)
        value_ = []
        if key != 'outcome':
            for val in value:
                val = float((val - drugCacheData[key]['avg'])/(drugCacheData[key]['std']+0.000001))
                value_.append(val)
            H[key] = value_
        elif key == 'outcome':
            y = value
            for j in range(len(value)):
                valJ = [value[j]]
                Y[features[0][j+1]] = valJ

    return H, Y, y, queryNames

def test_set(projName, modelLoc, cacheLoc, testFile):
    FeatureMatrix, OutcometMatrix, OutcomeArray, queryNames = readCsv(projName, cacheLoc, testFile)
    drugMarkers = {}
    comboDrugMoa = {}
    if True:
        np_array = []
        try:
            with open(os.path.join(modelLoc, projName+'.mwa'),'rb') as target:
                np_array = pickle.load(target)
            coeff = np_array[-1][0]
            key_v =  np_array[0]
        except:
            print("Prediction model not found in given location: ", modelLoc, projName)
            exit(0)
        NewMatrix = []
        for key in sorted(key_v):
            if key not in FeatureMatrix:
                print("Mismatch found in model params and input file...")
                exit(-1)
            else:
                array_ = FeatureMatrix[key]
                NewMatrix.append(array_)
        newMatrix = NP.matrix(NewMatrix)
        coefMatrix = NP.matrix(coeff)
        predicted = coefMatrix * newMatrix
        values = predicted.tolist()
        with open(os.path.join(str(projName)+"_report.txt"),'a') as fo:
            for i in range(len(values[0])):
                fo.write("GeneName\t"+projName+"\tMutation-Signature\t"+queryNames[i]+"\tPredicted_Value\t"+str(values[0][i])+"\tPredicted-Functionality\t"+str(marginalize(values[0][i]))+'\n')
                print("\n\n##############################################################################\n")
                print("GeneName :",projName,"Mutation-Signature :",queryNames[i],"Predicted-Value :",values[0][i] ,"Predicted-Functionality", marginalize(values[0][i]))
                print("\n##############################################################################\n\n")
    #except:
    #       print "Something went wrong..."


if __name__=="__main__":
    script, projName, modelLoc, cacheLoc, testfile = sys.argv

    try:
        test_set(projName, modelLoc, cacheLoc, testfile)
    except:
        raise ValueError

#EOF
