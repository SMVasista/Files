
import sys, os, re, math, random, operator, pickle
import regression as reg
import cwgutils

kvalue = 1000

def parseInputs(inputfile):
    fileData = cwgutils.readLinesAndSplit(inputfile, ',')
    QRSnv = []
    QRSv = []
    for line in fileData:
        if list(line[0])[0] != '#':
            if len(line) < 2:
                print("<ProjectName>,<Training-Matrix>,<Validation-Matrix#Optional>")
                exit(0)
            if len(line) == 2:
                QRSnv.append((line[0], line[1]))
            if len(line) == 3:
                QRSv.append((line[0], line[1], line[2]))
    return QRSv, QRSnv

def initiateModelBuilding(drugName, Datafile, kvalue):
    reg.train_set(drugName, Datafile, kvalue)


def initiateValidation(drugName, Datafile, model):
    reg.validate_set(drugName, Datafile, model)

if __name__=="__main__":
    script, inputfile = sys.argv
    Q1, Q2 = parseInputs(inputfile)
    for query in Q1:
        print("\n\n\n#############################################\n\tBuilding Model For: ", query[0],"\t\t\n#############################################\n\n\n")
        try:
            initiateModelBuilding(query[0], query[1], kvalue)
            initiateValidation(query[0], query[2], query[0]+'.mwa')
        except:
            raise IOError
    for query in Q2:
        try:
            initiateModelBuilding(query[0], query[1], kvalue)
        except:
            raise IOError
