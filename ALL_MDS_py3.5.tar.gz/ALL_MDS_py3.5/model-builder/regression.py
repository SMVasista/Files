
import sys, os, re, math, random, operator, pickle
import numpy as NP
NP.seterr(divide='ignore', invalid='ignore')
import cwgutils
import subprocess
import shlex
#Datafile format
#features : rows
#samples : columns
#outcome in row-name "outcome"

#Global
#version = 'LC_ONCO_V17.3.3'
cwd = os.getcwd()

def readCsv(datafile, drugName):
    H = {}
    Y = {}
    y = 0
    features = cwgutils.readLinesAndSplit(datafile, ',')
    try:
        with open(os.path.join(str(drugName)+'.ma.cache'), 'rb') as f:
            drugCacheData = pickle.load(f)
    except:
        print("Moving-Average cache for bio-markers not found. Results may not be accurate...")
        drugCacheData = {}

    for i in range(1, len(features)):
        key, value = cwgutils.reHeadArray(features[i])

        if key not in drugCacheData:
            drugCacheData[key] = {'std' : 1.0, 'avg': 0.0}

        value = cwgutils.mapToFloat(value)
        value_ = []
        if key != 'outcome':
            if NP.std(value) != 0.0:
                for val in value:
                    val = float((val - drugCacheData[key]['avg'])/(drugCacheData[key]['std']+0.00000001))
                    value_.append(val)
            else:
                for val in value:
                    val = float(val - drugCacheData[key]['avg'])
                    value_.append(val)
            H[key] = value_
        elif key == 'outcome':
            y = value
            for j in range(len(value)):
                valJ = [value[j]]
                Y[features[0][j+1]] = valJ
    return H, Y,y

def readCsvAndNormalize(drugName, datafile):
    H = {}
    Y = {}
    y = 0
    cache = {}
    features = cwgutils.readLinesAndSplit(datafile, ',')
    for i in range(1, len(features)):
        key, value = cwgutils.reHeadArray(features[i])
        value = cwgutils.mapToFloat(value)
        value_ = []
        if key != 'outcome':
            if NP.std(value) != '0':
                for val in value:
                    val = float((val - NP.mean(value))/NP.std(value))
                    value_.append(val)
                    if key not in list(cache.keys()):
                        cache[key] = {'avg': float(NP.mean(value)), 'std': float(NP.std(value))}
            else:
                for val in value:
                    val = float(val - NP.mean(value))
                    value_.append(val)
                    if key not in list(cache.keys()):
                        cache[key] = {'avg': float(NP.mean(value)), 'std': float(NP.std(value))}
            H[key] = value_
        elif key == 'outcome':
            y = value
            for j in range(len(value)):
                valJ = [value[j]]
                Y[features[0][j+1]] = valJ
    with open(os.path.join(drugName+'.ma.cache'),'wb') as f:
        pickle.dump(cache, f)

    return H, Y,y


def reduceFeatureDimension(fMatrix, yArray, searchThreshold, pType):
    #Identifies those feature elements that has a high correlation with the outcome and filters them into a reduced matrix
    fMatrixRed = {}
    selectedFeatures = []
    featureCorrelDict = {}
    Topop = []
    if pType == 'filter':
        for element in fMatrix:
            add_signal = 1
            correl = NP.corrcoef(NP.array(fMatrix[element]), NP.array(yArray))[0][1]
            if correl != 'nan':
                if abs(correl) >= searchThreshold:
                    if len(selectedFeatures) > 0:
                        for j in range(len(selectedFeatures)):
                            sub_correl = NP.corrcoef(NP.array(fMatrix[element]), NP.array(fMatrix[selectedFeatures[j]]))[0][1]
                            if sub_correl >= 0.5:
                                add_signal = 0
                        if add_signal != 0:
                            selectedFeatures.append(element)
                    else:
                        selectedFeatures.append(element)

        #Reorganizes matrix
        for element in sorted(selectedFeatures):
            fMatrixRed[element] = fMatrix[element]

    elif pType == 'pseudo':
        print("***Running Psudo-Feature selection***")
        for element in fMatrix:
            try:
                correl = float(NP.corrcoef(NP.array(fMatrix[element]), NP.array(yArray))[0][1])
                if not math.isnan(correl):
                    featureCorrelDict[element] = correl
            except:
                pass

        sortedFeatures = sorted(list(featureCorrelDict.items()), key=lambda x:x[1])

        a = sortedFeatures

        for v in a:
            selectedFeatures.append(v[0])

        for element in sorted(selectedFeatures):
            fMatrixRed[element] = fMatrix[element]


    return sorted(selectedFeatures), fMatrixRed


def createCrossValidationSet(fMatrix, yArray, tSizeFraction, trials):
    #Identify sample size
    TrainMatrixHolder = {}
    TrainOutcomeHolder = {}
    TestMatrixHolder = {}
    TestOutcomeHolder = {}
    for element in fMatrix:
        sampleSize = len(fMatrix[element])
        break
    trainingSize = int(round(sampleSize*(1-tSizeFraction)))
    testSize = int(sampleSize - trainingSize)
    print("Training size: ", trainingSize, " Test size: ", testSize)

    for i in range(trials):
        selectedIndex = []
        while len(selectedIndex) != trainingSize:
            num = random.randint(0,sampleSize-1)
            if num not in selectedIndex:
                selectedIndex.append(int(num))

        fMatrix_ = []
        for element in sorted(fMatrix.keys()):
            array_ = []
            yArray_ = []
            for index in selectedIndex:
                array_.append(float(fMatrix[element][index]))
                yArray_.append([yArray[index]])
            fMatrix_.append(array_)

        tMatrix_ = []
        for element in sorted(fMatrix.keys()):
            array_ = []
            tArray_ = []
            for num in range(sampleSize):
                #if num not in selectedIndex:
                array_.append(float(fMatrix[element][num]))
                tArray_.append([yArray[num]])
            tMatrix_.append(array_)

        TrainMatrixHolder[str(i)] = fMatrix_
        TrainOutcomeHolder[str(i)] = yArray_
        TestMatrixHolder[str(i)] = tMatrix_
        TestOutcomeHolder[str(i)] = tArray_

    return TrainMatrixHolder, TrainOutcomeHolder, TestMatrixHolder, TestOutcomeHolder

def estimateCoefficients(TrainMatrixHolder, TrainOutcomeHolder, TestMatrixHolder, TestOutcomeHolder):
    computedWeights = []
    #print TrainMatrixHolder
    for trialID in list(TrainMatrixHolder.keys()):
        A = NP.matrix(TrainMatrixHolder[trialID])
        y = NP.matrix(TrainOutcomeHolder[trialID])
        ####MLE Computation Ax = B --> A'Ax = A'B --> x = inv(A'A).A'B####
        ##################################################################
        W = (y.T)*(A.I)
        ##################################################################
        P = NP.matrix(TestMatrixHolder[trialID])
        o = NP.matrix(TestOutcomeHolder[trialID])
        c = NP.mean(y.T)
        predicted = W*P
        correl = NP.corrcoef((NP.array(o)).T, NP.array(predicted))[0][1]
        numW = len(W)
        if correl > 0.4:
            computedWeights.append(NP.array(W))

    for i in range(numW):
        val = 0
        for element in computedWeights:
            val += element
        generalizedWeights = val/(len(computedWeights)+0.001)
    predicted_ = generalizedWeights*P
    correl = NP.corrcoef((NP.array(o)).T, NP.array(predicted_))[0][1]
    print("\n", predicted_, "###", correl)
    #print o.T
    try:
        return generalizedWeights.tolist()
    except:
        return generalizedWeights

def writeStatistics(correlMatrix, drugName):
    with open(os.path.join(str(drugName)+'_validation_report.txt'),'w') as f:
        entry = [(v[1], v[2]) for v in correlMatrix]
        accuracy = len([v[1]  for v in entry if v[0]*v[1] > 0])*100/len(entry)
        ppv = len([v[1]  for v in entry if v[0]*v[1] > 0 and v[1] > 0])*100/len([v[1]  for v in entry if v[1] > 0])
        npv = len([v[1]  for v in entry if v[0]*v[1] > 0 and v[1] < 0])*100/len([v[1]  for v in entry if v[1] < 0])
        f.write('Accuracy: '+str(accuracy)+'\n'+'PPV: '+str(ppv)+'\n'+'NPV: '+str(npv))


def train_set(drugName, Datafile, kvalue):
    FeatureMatrix, OutcometMatrix, OutcomeArray = readCsvAndNormalize(drugName, Datafile)
    featuresLength = 0
    searchThresold = 0.65
    trial = 0
    while featuresLength < 30:
        featuresList, NewFeaturesMatrix = reduceFeatureDimension(FeatureMatrix, OutcomeArray, searchThresold, pType='pseudo')
        print("~~~", searchThresold, featuresList, NewFeaturesMatrix)
        featuresLength = len(featuresList)
        searchThresold -= 0.05
        trial += 1
        if trial == 8:
            break
    print("Identified", featuresLength, "Features for building regression model")

    if featuresLength < 1:
        featuresList, NewFeaturesMatrix = reduceFeatureDimension(FeatureMatrix, OutcomeArray, 0.0, pType='pseudo')

        print("(Re)Identified", len(featuresList), "Features for building regression model")

    TrainingMatrixSet, TrainingOutcomeSet, TestMatrixSet, TestOutcomeSet = createCrossValidationSet(NewFeaturesMatrix, OutcomeArray, 0.2, int(kvalue))
    WeighCoeff = estimateCoefficients(TrainingMatrixSet, TrainingOutcomeSet, TestMatrixSet, TestOutcomeSet)
    WeightDict = []
    WeightDict.append(featuresList)
    WeightDict.append(WeighCoeff)
    with open(os.path.join(drugName+'.mwa'),'wb') as target:
        pickle.dump(WeightDict, target)

def validate_set(drugName, testfile, filename):
    FeatureMatrix, OutcometMatrix, OutcomeArray = readCsv(testfile, drugName)
    np_array = []
    with open(os.path.join(filename),'rb') as target:
        np_array = pickle.load(target)
    coeff = np_array[-1][0]
    key_v =  np_array[0]
    NewMatrix = []
    for key in sorted(key_v):
        if key not in FeatureMatrix:
            exit(-1)
        else:
            array_ = FeatureMatrix[key]
            NewMatrix.append(array_)

    newMatrix = NP.matrix(NewMatrix)
    coefMatrix = NP.matrix(coeff)
    predicted = coefMatrix * newMatrix
    #print predicted
    correl = NP.corrcoef((NP.array(OutcomeArray)).T, NP.array(predicted[0]))[0][1]
    #print (predicted[0][0])

    OutcomeMatrixUpdated = []

    print(OutcometMatrix)
    print(predicted)

    for i in range(len(OutcomeArray)):
        OutcomeMatrixUpdated.append(('q', OutcomeArray[i], predicted[0][0].tolist()[0][i]))

    with open(os.path.join(str(drugName)+'_predicted.p'),'wb') as f:
        pickle.dump(OutcomeMatrixUpdated, f)

    writeStatistics(OutcomeMatrixUpdated, drugName)

if __name__=="__main__":
    if len(sys.argv) != 4:
        print("Usage  \nTraining Mode: <Drug/Modality-Name> <Labeled-Data-Loc> <1>\nTest/Validate Mode: <Drug/Modality-Name> <Labeled-Data-Loc> <2>")
    else:
        script, drugName, Datafile, mode = sys.argv
        kvalue = 1000
        #n = int(input("Want to create Trainset[1]:\nWant to validate or Check correlation[2]:\n"))

        if mode == '1':
            train_set(drugName, Datafile, kvalue)

        elif mode == '2':
            filename = str(drugName)+'.mwa'
            validate_set(drugName, Datafile, model)
        else:
            print("Wrong Input")
            exit(0)
