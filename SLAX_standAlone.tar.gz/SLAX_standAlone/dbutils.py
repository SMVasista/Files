from mysql.connector import connection
import cwgutils
import json
from datetime import date,datetime

# make sure mysql is running on port 3306 - default port

class DbUtils:
    cnx = None

    @classmethod
    def readConfig(cls, cfgFile='./dbutils.cfg'):
        config = {}
        lines = cwgutils.readLines(cfgFile)
        for line in lines:
            if '=' in line and line[0] != '#':
                key,value = line.split('=')
                config[key.strip()] = value.strip()
        return config

    def __init__(self, cfgFile='./dbutils.cfg'):
        if DbUtils.cnx == None:
            config = DbUtils.readConfig(cfgFile)
            #print '=======', config
            DbUtils.cnx = connection.MySQLConnection(user=config["user"], password=config["password"], host=config["host"], database=config["database"])

    @classmethod
    def rowToDict(cls, columnNames, row):
        newrow = []
        for item in row:
            if isinstance(item, date):
                newrow.append(item.isoformat())
            else:
                newrow.append(item)
        return dict(zip(columnNames, newrow))

    # where has to always begin with WHERE and it should be a valid clause
    @classmethod
    def select(cls, cursor, table, where='', fields='*', order_by='', group_by='', start=0, limit=-1, is_distinct=False):
        params = {}
        cmd = 'SELECT '

        if is_distinct == True:
            cmd += ' DISTINCT '

        if fields == None or (isinstance(fields, str) and fields == '*'):
            cmd += '* '
        elif isinstance(fields, str):
            cmd += (fields + ' ')
        elif isinstance(fields, list):
            if len(fields) > 0:
                cmd += (','.join(fields) + ' ')
            else:
                cmd += '* '

        cmd += 'FROM ' + table
        if len(where) > 0:
            cmd += (' ' + where)

        if group_by != '':
            cmd += ' GROUP BY %(group_by)s'
            params['group_by'] = group_by

        if order_by != '':
            cmd += ' ORDER BY %(order_by)s'
            params['order_by'] = order_by

        if limit > 0:
            cmd += 'LIMIT %(start)s,%(limit)s'
            params['start'] = start
            params['limit'] = limit

        print cmd
        rows = []

        cursor.execute(cmd, params)
        for row in cursor:
            rows.append(DbUtils.rowToDict(cursor.column_names, row))
        return rows


    # this method is for raw query like "SELECT * FROM PET" or complex queries involving JOIN
    @classmethod
    def query(cls, cursor, queryStr):
        cursor.execute(queryStr)
        rows = cursor.fetchall()
        return [ DbUtils.rowToDict(cursor.column_names, row) for row in rows]

    @classmethod
    def insert(cls, cursor, table_name, row):
        cmd = 'INSERT INTO ' + table_name + ' (' + ','.join(row.keys()) + ') VALUES (';
        kys = [ '%(' + k + ')s' for k in row.keys()]
        cmd += ','.join(kys) + ')'
        print cmd
        cursor.execute(cmd, row)
        rowid = cursor.lastrowid

    @classmethod
    def cursor(cls):
        return DbUtils.cnx.cursor()

    @classmethod
    def commit(cls):
        DbUtils.cnx.commit()
