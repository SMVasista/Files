from __future__ import division
import sys, os, math, operator, copy, pickle
from collections import Counter
import cwgutils

#Global
impurity_allowance = 0.05

def readCsv(datafile):
	#H : Features Matrix
	#Y : Sample Mapped to Outcome
	#y : Outcome as an array
	H = {}
	Y = {}
	features = cwgutils.readLinesAndSplit(datafile, ',')
	for i in range(1, len(features)):
		key, value = cwgutils.reHeadArray(features[i])
		if key != 'outcome':
			H[key] = value
		elif key == 'outcome':
			y = value
			for j in range(len(value)):
				valJ = value[j]
				Y[features[0][j+1]] = valJ
	return H, Y, y

def Entropy(array):
	P = {}
	entropy = 0
	types = list(set(array))
	toLen = len(array)
	if toLen != 0:
		for typ in types:
			P[typ] = array.count(typ)/toLen * math.log((array.count(typ)/toLen))
			entropy += P[typ]
		entropy = -1*entropy
	else:
		entropy = 1
	return float(entropy)
		

def InfGain(fNoiseDict, featureEnt, rootEnt, y):
	infoGain = 0
	for element in featureEnt:
		for typ in y:
			infoGain -= (fNoiseDict[element].count(typ)/len(y)*featureEnt[element])
	infoGain += rootEnt
	return float(infoGain)

def calculateDecisionFeatures(H,Y,y, treeSize, RootFeatures):
	#Since elements of Rootfeatures are already traced in parallel trees, we will avoid these in the new trees
	FEATURE_ATTR = {}
	FEATURE_ENTROPY = {}
	FEATURE_INFGAIN = {}
	FEATURE_ATTR_NOISEARRAY = {}

	rootEntropy = Entropy(y)

	for feature in sorted(H.keys()):
		FEATURE_ATTR[feature] = list(set(H[feature]))
		FEATURE_ENTROPY[feature] = {}
		FEATURE_ATTR_NOISEARRAY[feature] = {}
		
		for attr in FEATURE_ATTR[feature]:
			noiseArray = []
			for i in range(len(y)):
				if H[feature][i] == attr:
					noiseArray.append(y[i]) 
			FEATURE_ENTROPY[feature][attr] = Entropy(noiseArray)
			FEATURE_ATTR_NOISEARRAY[feature][attr] = noiseArray

		FEATURE_INFGAIN[feature] = InfGain(FEATURE_ATTR_NOISEARRAY[feature], FEATURE_ENTROPY[feature], rootEntropy, y)
	featureGainOrdered = sorted(FEATURE_INFGAIN.items(), key=lambda x:x[1], reverse=True)
	#print featureGainOrdered
	featureSelected = []
	if len(RootFeatures) != 0:
		while len(featureSelected) != treeSize:
			if featureGainOrdered[0][0] not in RootFeatures:
				featureSelected.append(featureGainOrdered[0][0])
			featureGainOrdered.pop(0)
	else:
		for i in range(treeSize):
			featureSelected.append(featureGainOrdered[i][0])


	return FEATURE_ATTR_NOISEARRAY, featureSelected

def createSubMatrix(feature, attr, FEATURE_ATTR_NOISEARRAY, H, Y, y):
	SUB_MATRIX = {}
	SUB_Y = []
	sub_matrix_index = []
	for features in H.keys():
		if features == feature:
			for j in range(len(H[feature])):
				if H[feature][j] == attr:
					sub_matrix_index.append(j)
	for element in H.keys():
		array_ = []
		for index in sub_matrix_index:
			array_.append(H[element][index])
		SUB_MATRIX[element] = array_

	for j in sub_matrix_index:
		SUB_Y.append(y[j])

	return SUB_MATRIX, SUB_Y

def buildRecurviseTrees(selectedFeatures, NoiseArray, H, Y, y):
	TREES = {}
	FEATURE_COLLECTOR = []
	RootFeature = copy.deepcopy(selectedFeatures)
	for feature in selectedFeatures:
		if feature not in FEATURE_COLLECTOR:
			FEATURE_COLLECTOR.append(feature)
		TREES[feature] = {}
		for attr in NoiseArray[feature]:
			if attr != '':
				TREES[feature][attr] = {}
			entropy = Entropy(NoiseArray[feature][attr])
			if abs(entropy) == 0:
				if attr != '':
					most_common,num_most_common = Counter(NoiseArray[feature][attr]).most_common(1)[0]
					TREES[feature][attr][most_common] = (float(num_most_common/(len(NoiseArray[feature][attr])+0.0001)), len(NoiseArray[feature][attr]))
			else:
				sub_matrix, sub_y = createSubMatrix(feature, attr, NoiseArray, H, Y, y)
				NewNoiseArray, NewSelectedFeatures = calculateDecisionFeatures(sub_matrix, Y, sub_y, 1, RootFeature)
				RootFeature = list(set(RootFeature + NewSelectedFeatures))
				for Newfeature in NewSelectedFeatures:
					if Newfeature not in FEATURE_COLLECTOR:
						FEATURE_COLLECTOR.append(Newfeature)
					TREES[feature][attr][Newfeature] = {}
					for sattr in NewNoiseArray[Newfeature]:
						TREES[feature][attr][Newfeature][sattr] = {}
						entropy = Entropy(NewNoiseArray[Newfeature][sattr])
						if abs(entropy) == 0:
							if sattr != '':
								most_common,num_most_common = Counter(NewNoiseArray[Newfeature][sattr]).most_common(1)[0]
								TREES[feature][attr][Newfeature][sattr][most_common] = (float(num_most_common/(len(NewNoiseArray[Newfeature][sattr])+0.0001)), len(NewNoiseArray[Newfeature][sattr]))
						else:
							new_sub_matrix, new_sub_y = createSubMatrix(Newfeature, sattr, NewNoiseArray, H, Y, y)
							NNewNoiseArray, NNewSelectedFeatures = calculateDecisionFeatures(new_sub_matrix, Y, new_sub_y, 1, RootFeature)
							for sfeature in NNewSelectedFeatures:
								if sfeature not in FEATURE_COLLECTOR:
									FEATURE_COLLECTOR.append(sfeature)
								TREES[feature][attr][Newfeature][sattr][sfeature] = {}
								for dwn in NNewNoiseArray[sfeature]:
									TREES[feature][attr][Newfeature][sattr][sfeature][dwn] = {}
									most_common,num_most_common = Counter(NNewNoiseArray[sfeature][dwn]).most_common(1)[0]
									print dwn, most_common, num_most_common
									TREES[feature][attr][Newfeature][sattr][sfeature][dwn][most_common] = (float(num_most_common/(len(NNewNoiseArray[sfeature][dwn])+0.0001)), len(NNewNoiseArray[sfeature][dwn]))
	return TREES, FEATURE_COLLECTOR

def writeModel(relModel):
	with open('./Relationship_Model.p','w') as f:
		pickle.dump(relModel,f)

if __name__=="__main__":
	script, datafile, treeSize = sys.argv
	H, Y, y = readCsv(datafile)
	OUTCOMES = list(set(y))
	if '' in OUTCOMES:
		OUTCOMES.pop(OUTCOMES.index(''))
	RootFeature = []
	NoiseArray, selectedFeatures = calculateDecisionFeatures(H, Y, y, int(treeSize), RootFeature)
	print selectedFeatures
	TREES, ATTRIBUTES = buildRecurviseTrees(selectedFeatures, NoiseArray, H, Y, y)
	DATA = [TREES, ATTRIBUTES, OUTCOMES]
	print TREES
	writeModel(DATA)


