from __future__ import division
import re, math, sys, pickle, os, time
import subprocess
import slax_feature_normalizer

##Data Read functions

def readPickleData(patientList, location):
	Data = {}
	for patient in patientList:
		with open(os.path.join(location,patient),'r') as f:
			data = pickle.load(f)
		Data[patient] = data
	return Data

def readLabelData(icoginputfile):
	patientList = cwgutils.readColumn(icoginputfile, 0, ',')
	responseList = cwgutils.readColumn(icoginputfile, 1, ',')
	Response = dict(zip(patientList, responseList))
	return patientList, Response

def extractFeatures(rawData, enforcedFeature):
	classifiedLabelData = {}

	features = []
	for element in rawData.keys():
		for feature in rawData[element]:
			if feature not in features:
				features.append(feature)
	features = list(set(features + enforcedFeature))

	for element in rawData:
		classifiedLabelData[element] = {}
		for feature in features:
			if feature in rawData[element]:
				classifiedLabelData[element][feature] = 'Yes'
			else:
				classifiedLabelData[element][feature] = 'No'
	return features, classifiedLabelData

def downloadDecisionTreeObject(version, rootnode):
	cwl=os.getcwd()
	svnloc = os.path.join(str(rootnode), str(version))
	process = "svn co "+svnloc+" ./etpr.dt.temp"
	if not os.path.exists(os.path.join(cwl,'etpr.dt.temp')):
		p = subprocess.Popen('mkdir ./etpr.dt.temp', shell=True)
		try:
			p = subprocess.Popen(process, subprocess.PIPE, shell=True)
		except:
			exit(0)


def clearEntropyData():
	p = subprocess.Popen('rm -rf ./etpr.dt.temp', shell=True)

###Predictor Utils

def loadModel(location, modelName):
	with open(os.path.join(location, modelName)+'.dt.p', 'r') as f:
		model = pickle.load(f)
	relationmodel = model[0]
	attributes = model[1]
	outcomes = model[2]
	return relationmodel, attributes, outcomes

def loadPatient(location, patientName):
	with open(os.path.join(location, patientName), 'r') as f:
		patient = pickle.load(f)
	return patient

def reconstructFeatures(Data, attributes):

	#Normalizing Patient Data
	testPatientFeatures, TestLabelData = extractFeatures(Data, attributes)

	return TestLabelData['patient']

def testEntropyData(entropyData, testClassifiedData, patientData):
	predictionScore = {}
	DTREE = entropyData[0]
	OUTCOME = entropyData[2]
	for patient in testClassifiedData:
		patientFeatures = testClassifiedData[patient]
		verdict = traverseDecisionTrees(DTREE, patientFeatures, OUTCOME)
		Decision = decide(verdict)
		print Decision
		if Decision[0] != None:
			if Decision[0] == patientData[patient] or Decision[0]+'\n' == patientData[patient]:
				if patientData[patient] == 'R':
					predictionScore[patient] = 1
				elif patientData[patient] == 'N':
					predictionScore[patient] = 1
			else:
				if patientData[patient] == 'R':
					predictionScore[patient] = -1
				elif patientData[patient] == 'N':
					predictionScore[patient] = -1
		else:
			predictionScore[patient] = 'NA'
		try:
			print patient, predictionScore[patient]
		except:
			print patient, "not found in list"

	correl = float(predictionScore.values().count(1)/(0.01+len(predictionScore.values())))

	return correl, predictionScore

def integrateEntropyTrees(EntropyTreeSet):
	integratedTree = {}
	integratedAttr = []
	integratedOut = []
	for treeSet in EntropyTreeSet:
		for dTree in treeSet[0][0]:
			integratedTree[dTree] = treeSet[0][0][dTree]
	for treeSet in EntropyTreeSet:
		integratedAttr = integratedAttr+treeSet[0][1]
		integratedOut = integratedOut+treeSet[0][2]
	return [integratedTree, list(set(integratedAttr)), list(set(integratedOut))]
			

def traverseDecisionTrees(relationmodel, patient, Outcome):
	#Loading Roots
	roots = relationmodel.keys()
	voters = len(roots)

	decision = {}
	for predictor in roots:
		query = patient[predictor]
		if query in relationmodel[predictor]:
			if relationmodel[predictor][query].keys()[0] in Outcome:
				decision[predictor] = relationmodel[predictor][query]
			else:
				for subtype in relationmodel[predictor][query]:
					subquery = patient[subtype]
					if subquery in relationmodel[predictor][query][subtype]:
						if relationmodel[predictor][query][subtype][subquery].keys()[0] in Outcome:
							decision[predictor] = relationmodel[predictor][query][subtype][subquery]
						else:
							for subsubtype in relationmodel[predictor][query][subtype][subquery]:
								subsubquery = patient[subsubtype]
								if subsubquery in relationmodel[predictor][query][subtype][subquery][subsubtype]:
									if relationmodel[predictor][query][subtype][subquery][subsubtype][subsubquery].keys()[0] in Outcome:
										decision[predictor] = relationmodel[predictor][query][subtype][subquery][subsubtype][subsubquery]

	return decision

def decide(verdict):
	MaxVote = {}
	total = 0.00001
	for predictor in verdict:
		print "\t\t\t", predictor, verdict[predictor], verdict[predictor].values(), verdict[predictor].values()[0][0]
		if verdict[predictor].keys()[0] not in MaxVote.keys():
			MaxVote[verdict[predictor].keys()[0]] = float(0.1*verdict[predictor].values()[0][0]**4)#*verdict[predictor].values()[0][0]**4)
		else:
			MaxVote[verdict[predictor].keys()[0]] += float(0.1*verdict[predictor].values()[0][0]**4)#*verdict[predictor].values()[0][0]**4)
	MaxVote = sorted(MaxVote.items(), key=lambda x:x[1], reverse=True)
	for elem in MaxVote:
		total += elem[1]
	try:
		return MaxVote[0][0], float(MaxVote[0][1]/total)
	except:
		return None, None


##MAIN function

def calculateEntropyScore(patientObj, drug, version):
	cwl = os.getcwd()

	#Create Virtual Patient Pathways Map
	patient = {}
	for pName in patientObj["pathwaysmap"]:
		patient[pName] = patientObj["pathwaysmap"][pName]["score"]
		
	Data = {}
	Data['patient'] = patient
	
	try:
		DTREE, Attributes, Outcome = loadModel(os.path.join(cwl,'etpr.dt.temp'), drug)
		extractedPatient = reconstructFeatures(Data, Attributes)
		verdict = traverseDecisionTrees(DTREE, extractedPatient, Outcome)
		Decision = decide(verdict)
	except:
		print "Entropy :: Error while accessing drug: ", drug
		with open('./icog_error.log','a') as f:
			msg = str(time.strftime('%Y.%m.%d|%H.%m'))+':: Entropy :: Error while accessing drug:', drug, ' Skipping'
			f.write(str(msg)+'\n')
		Decision = ('A', 0.0) 
	
	return Decision

def reCalibrateScore(score):
	#Assumes score is a tuple
	if score[0] == 'R' or score[0] == 'L' or score[0] == 'VL':
		return float(1*score[1])
	elif score[0] == 'M':
		return float(0.1*score[1])
	elif score[0] == 'N' or score[0] == 'H' or score[0] == 'VH':
		return float(-1*score[1])
	else:
		print "Score meter undefined: Returning original value"
		return float(score[1])


##Other functions

def writeFeaturesFile(features, classifiedLabelData, Response):
	with open('./features.etrp.csv','a') as target:
		target.write(',')
		for patient in sorted(classifiedLabelData.keys()):
			target.write(str(patient)+',')
		target.write('\n')
		for feature in features:
			target.write(str(feature)+',')
			for patient in sorted(classifiedLabelData.keys()):
				try:
					target.write(str(classifiedLabelData[patient][feature])+',')
				except:
					target.write('NORMAL'+',')
			target.write('\n')
		target.write('outcome'+',')
		for patient in sorted(classifiedLabelData.keys()):
			target.write(str(Response[patient])+',')

