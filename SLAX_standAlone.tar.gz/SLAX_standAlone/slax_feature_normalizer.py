from __future__ import division
import sys, os, re, pickle, copy
import cwgutils

def readPickleData(patientList, location):
	Data = {}
	for patient in patientList:
		with open(os.path.join(location,patient),'r') as f:
			data = pickle.load(f)
		Data[patient] = data
	return Data

def readLabelData(icoginputfile):
	patientList = cwgutils.readColumn(icoginputfile, 0, ',')
	responseList = cwgutils.readColumn(icoginputfile, 1, ',')
	Response = dict(zip(patientList, responseList))
	return patientList, Response

def extractFeatures(Data, enforcedFeature):
	classifiedLabelData = {}

	features = []
	for element in Data:
		for feature in Data[element]:
			if feature not in features:
				features.append(feature)
	features = list(set(features + enforcedFeature))

	for element in Data:
		classifiedLabelData[element] = {}
		for feature in features:
			if feature not in Data[element].keys() or Data[element][feature] == 0.0:
				classifiedLabelData[element][feature] = 'NORMAL'
			elif Data[element][feature] > 0:
				classifiedLabelData[element][feature] = 'HIGH'
			elif Data[element][feature] < 0:
				classifiedLabelData[element][feature] = 'LOW'
	return features, classifiedLabelData

def writeFeaturesFile(features, classifiedLabelData, Response):
	with open('./features.etrp.csv','a') as target:
		target.write(',')
		for patient in sorted(classifiedLabelData.keys()):
			target.write(str(patient)+',')
		target.write('\n')
		for feature in features:
			target.write(str(feature)+',')
			for patient in sorted(classifiedLabelData.keys()):
				try:
					target.write(str(classifiedLabelData[patient][feature])+',')
				except:
					target.write('NORMAL'+',')
			target.write('\n')
		target.write('outcome'+',')
		for patient in sorted(classifiedLabelData.keys()):
			target.write(str(Response[patient])+',')

if __name__=="__main__":
	script, icoginputfile, patientlocation = sys.argv
	patientList, Response = readLabelData(icoginputfile)
	Data = readPickleData(patientList, patientlocation)
	dummy = []
	features, LabelData = extractFeatures(Data, dummy)
	writeFeaturesFile(features, LabelData, Response)
