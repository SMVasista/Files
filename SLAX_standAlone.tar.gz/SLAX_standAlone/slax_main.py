from __future__ import division
import sys, os, random, re, copy, subprocess, pickle

###############################
from dbutils import DbUtils
import slax_dtconstructor as DTB
import slax_entropyutils
import slax_read_utils as SRD
import slax_predictor

import cwgpatient
import cwgutils
###############################

DbUtils()
cursor = DbUtils.cursor()

def initiate_slax_learning(trainSet, testSet, blindedSet, dataSource):

	#Checking Inputs
	totalList = list(set(trainSet.keys()+testSet.keys()+blindedSet.keys()))
	for pId in totalList:
		if os.path.isfile(os.path.join(dataSource, pId+'.csv')) == False:
			print pId, "inputs not found in location"
			if pId in trainSet.keys():
				del trainSet[pId]
			elif pId in testSet.keys():
				del testSet[pId]
			elif pId in blindedSet.keys():
				del blindedSet[pId]

	if len(trainSet.keys())*len(testSet.keys())*len(blindedSet.keys()) <= 0:
		exit(-1)

	Entropy = {}
	Data = {}
	attributes = []
	for patient in trainSet.keys():
		Data[patient] = []
		try:
			parsedData = SRD.parseData(patient, dataSource, 1)
		except:
			pass
		for pMap in parsedData:
			Data[patient].append(pMap)
			if pMap not in attributes:
				attributes.append(pMap)

	features, classifiedLabelData = slax_entropyutils.extractFeatures(Data, attributes)

	#Reformatting for DTB

	H = {}

	for feature in features:
		featureSamples = []
		for patient in sorted(classifiedLabelData.keys()):
			featureSamples.append(classifiedLabelData[patient][feature])
		H[feature] = featureSamples

	Y = {}
	y = []
	remove = []
	
	for patient in sorted(classifiedLabelData.keys()):
		if trainSet[patient] == 'R' or trainSet[patient] == 'R\n':
			outcome = 'R'
			y.append(outcome)
		elif trainSet[patient] == 'N' or trainSet[patient] == 'N\n':
			outcome = 'N' 
			y.append(outcome)

	OUTCOMES = list(set(y))

	#Initiating Entropy DT construction

	rootFeature = []
	#try:
	if True:
		NoiseArray, selectedFeatures = DTB.calculateDecisionFeatures(H, Y, y, 3, rootFeature)
		TREES, ATTRIBUTES = DTB.buildRecurviseTrees(selectedFeatures, NoiseArray, H, Y, y)

		ENTROPY_DATA = [TREES, ATTRIBUTES, OUTCOMES]

		#Test Set validation
		testData = {}
		testAttributes = []
		for patient in testSet.keys():
			testData[patient] = []
			try:
				parsedData = SRD.parseData(patient, dataSource, 1)
			except:
				pass
			for pMap in parsedData:
				testData[patient].append(pMap)
				if pMap not in testAttributes:
					testAttributes.append(pMap)
		testAttributes = list(set(ENTROPY_DATA[1]+testAttributes))

		features, testClassifiedLabelData = slax_entropyutils.extractFeatures(testData, testAttributes)
		Correl, Stats = slax_entropyutils.testEntropyData(ENTROPY_DATA, testClassifiedLabelData, testSet)
		print "Correlation: ", Correl
		Entropy = (ENTROPY_DATA, Correl, Stats)
		print Entropy
	#except:
	#	pass
	
	EntropyTreeSet = []

	cutOff = 0.7
	while len(EntropyTreeSet) < 2 and cutOff > 0:
		if Entropy >= cutOff:
			EntropyTreeSet.append((Entropy[0], (Entropy[1])))
		cutOff -= 0.05
	EntropyTreeSet = sorted(EntropyTreeSet, key=lambda x: x[1])

	iENTROPY_DATA = slax_entropyutils.integrateEntropyTrees(EntropyTreeSet)
	
	#Blind Set validation
	blindTestData = {}
	blindTestAttributes = []

	for patient in blindedSet.keys():
		blindTestData[patient] = []
		try:
			parsedData = SRD.parseData(patient, dataSource, 1)
		except:
			pass
		for pMap in parsedData:
			blindTestData[patient].append(pMap)
			if pMap not in blindTestAttributes:
				blindTestAttributes.append(pMap)
	blindTestAttributes = list(set(iENTROPY_DATA[1]+blindTestAttributes))

	features, testClassifiedLabelData = slax_entropyutils.extractFeatures(blindTestData, blindTestAttributes)
	blindCorrel, blindStats = slax_entropyutils.testEntropyData(iENTROPY_DATA, testClassifiedLabelData, blindedSet)
	print "##Entropy Blinded Correlation: ", blindCorrel

	return iENTROPY_DATA, blindCorrel, blindStats

def extract_datasets(drugName, extType):
	print "Extracting Data for: ", drugName
	Data = {}
	if extType == '0':
		qry = "SELECT PATIENT_ID,ACTUAL_RESPONSE FROM `DRUG_PATIENT_DATA` WHERE DRUG_NAME='"+str(drugName)+"' AND ACTUAL_RESPONSE != 'NULL'"
	    	rows = DbUtils.query(cursor, qry)
		if rows == None or len(rows) == 0:
			exit(0)
		else:
			for row in rows:
				Data[row["PATIENT_ID"]] = row["ACTUAL_RESPONSE"]
	elif extType == '1':
		dataLoc = raw_input('Data File: ')
		data = cwgutils.readLinesAndSplit(dataLoc, ',')
		for elem in data:
			Data[elem[0]] = elem[1]
			
	
	count = {}
	count['R'] = Data.values().count('R')+Data.values().count('R\n')
	count['N'] = Data.values().count('N')+Data.values().count('N\n')

	print count
	
	tailGroup = sorted(count.items(), key=lambda x:x[1])
	print tailGroup

	trainSet = {}

	for element in Data.keys():
		if Data[element] == tailGroup[0][0] or Data[element] == tailGroup[0][0]+'\n':
			trainSet[element] = tailGroup[0][0]
	print trainSet, len(trainSet.keys()), tailGroup, tailGroup[0], tailGroup[0][1], 2*int(tailGroup[0][1])

	sourceList = Data.keys()
	while len(trainSet.keys()) < 2*int(tailGroup[0][1]):
		rnd = random.randint(0, len(sourceList)-1)
		if sourceList[rnd] in Data.keys():
			if Data[sourceList[rnd]] == tailGroup[1][0] or Data[sourceList[rnd]] == tailGroup[1][0]+'\n':
				trainSet[sourceList[rnd]] = tailGroup[1][0]	
				del Data[sourceList[rnd]]


	cutOff = 0.3*len(trainSet.keys())

	testSet = {}

	pList = trainSet.keys()
	while len(testSet.keys()) < cutOff:
		key = random.randint(0, len(pList)-1)
		if pList[key] in trainSet.keys():
			testSet[pList[key]] = trainSet[pList[key]]
			del trainSet[pList[key]]
	
	cutOff = 0.9*len(testSet.keys())
	
	blindSet = {}

	pList = testSet.keys()
	while len(blindSet.keys()) < cutOff:
		key = random.randint(0, len(pList)-1)
		if pList[key] in testSet.keys():
			blindSet[pList[key]] = testSet[pList[key]]
			del testSet[pList[key]]

	print "Data distribution in Test set is:", "R", testSet.values().count('R'), "N", testSet.values().count('N')

	return trainSet, testSet, blindSet


if __name__=="__main__":
	script, drugName, dataSource = sys.argv
	extType = raw_input('From Database: [0]   From File: [1] <pid>,<R/N> :')
	TRAIN, TEST, BLIND = extract_datasets(drugName, extType)
	entropyData, correlation, stats = initiate_slax_learning(TRAIN, TEST, BLIND, dataSource)
	x = raw_input()
	with open(os.path.join(dataSource, drugName+'.slx'), 'w') as f:
		pickle.dump(entropyData, f)










