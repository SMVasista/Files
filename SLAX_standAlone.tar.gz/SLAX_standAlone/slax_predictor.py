from __future__ import division
import sys, os, math, operator, copy, pickle
from collections import Counter
import cwgutils
import slax_feature_normalizer

def loadModel(location, modelName):
	with open(os.path.join(location, modelName)+'.slx', 'r') as f:
		model = pickle.load(f)
	relationmodel = model[0]
	attributes = model[1]
	outcomes = model[2]
	return relationmodel, attributes, outcomes

def loadPatient(location, patientName):
	with open(os.path.join(location, patientName), 'r') as f:
		patient = pickle.load(f)
	return patient

def reconstructFeatures(attributes, patientname, patient):

	#Normalizing Patient Data
	Data = {}
	Data[patientname] = patient
	testPatientFeatures, TestLabelData = feature_normalizer.extractFeatures(Data, attributes)

	return TestLabelData[patientname]

def traverseDecisionTrees(relationmodel, patient, Outcome):
	#Loading Roots
	roots = relationmodel.keys()
	voters = len(roots)

	decision = {}
	for predictor in roots:
		query = patient[predictor]
		if query in relationmodel[predictor]:
			if relationmodel[predictor][query].keys()[0] in Outcome:
				decision[predictor] = relationmodel[predictor][query]
			else:
				for subtype in relationmodel[predictor][query]:
					subquery = patient[subtype]
					if subquery in relationmodel[predictor][query][subtype]:
						if relationmodel[predictor][query][subtype][subquery].keys()[0] in Outcome:
							decision[predictor] = relationmodel[predictor][query][subtype][subquery]
						else:
							for subsubtype in relationmodel[predictor][query][subtype][subquery]:
								subsubquery = patient[subsubtype]
								if subsubquery in relationmodel[predictor][query][subtype][subquery][subsubtype]:
									if relationmodel[predictor][query][subtype][subquery][subsubtype][subsubquery].keys()[0] in Outcome:
										decision[predictor] = relationmodel[predictor][query][subtype][subquery][subsubtype][subsubquery]

	return decision

def decide(verdict):
	MaxVote = {}
	for predictor in verdict:
		if verdict[predictor].keys()[0] not in MaxVote.keys():
			MaxVote[verdict[predictor].keys()[0]] = float(verdict[predictor].values()[0][0])#*math.tanh(verdict[predictor].values()[0][1]/10)**4)
		else:
			MaxVote[verdict[predictor].keys()[0]] += float(verdict[predictor].values()[0][0])#*math.tanh(verdict[predictor].values()[0][1]/10)**4)
	print "~~~~~~", MaxVote
	MaxVote = sorted(MaxVote.items(), key=lambda x:x[1], reverse=True)
	return MaxVote[0][0], MaxVote[0][1]

if __name__=="__main__":
	script, modelLocation, modelName, patientLocation, patientName = sys.argv
	DTREE, Attributes, Outcome = loadModel(modelLocation, modelName)
	PATIENT = loadPatient(patientLocation, patientName)
	extractedPatient = reconstructFeatures(Attributes, patientName, PATIENT)
	verdict = traverseDecisionTrees(DTREE, extractedPatient, Outcome)
	Decision = decide(verdict)
	print Decision
	#import quotes
