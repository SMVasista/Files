from __future__ import division
import cwgutils, os, re, sys, pickle, uuid
import numpy as NP

#Loading geneMap
try:
	with open('./geneMap.p','r') as f:
		geneMap = pickle.load(f)
except:
	print "Gene-Mapping data not found..."
	geneMap = {}

def parseGenomics(fileLoc):
	qualGenomics = []
	tempCNVGenomics = []
	tempMUTGenomics = []
	data = cwgutils.readLinesAndSplit(fileLoc, ',')
	for aberration in data:
		geneName = aberration[0]
		if 'CNV' in aberration and 'auto' in aberration:
			try:
				geneNameMod = geneMap[aberration[0]]
			except:
				print geneName, "Not changed"
				geneNameMod = geneName
			tempCNVGenomics.append((geneNameMod, aberration[1]))

		elif 'MUT' in aberration and 'auto' in aberration:
			tempMUTGenomics.append((geneName, str(aberration[1])+'-MUT'))

	for element in tempCNVGenomics:
		if tempCNVGenomics.count(element) >= 5:
			qualGenomics.append([element[0], element[1], 'auto'])
	for element in tempMUTGenomics:
		qualGenomics.append([element[0], element[1], 'auto'])

	if len(tempCNVGenomics) > 0 or len(tempMUTGenomics) > 0:
		return qualGenomics
	else:
		return data


def parseData(patientId, sourcelocation, critical):
	PatientDiscreetData = {}
	attributes = []
	clusterList = [patientId]
	for element in clusterList:
		print "Reading patient:", element
		PatientDiscreetData[element] = []
		genomicData = parseGenomics(os.path.join(sourcelocation, element+'.csv'))
		for abberation in genomicData:
			if "Mutation" not in abberation:
				if len(abberation) == 6:
					if abberation[0] != '':
						PatientDiscreetData[element].append(str(abberation[0])+'~'+str(abberation[1])+'~'+str(abberation[2]))
					elif abberation[1] != '':
						PatientDiscreetData[element].append(str(abberation[1])+'~'+str(abberation[2]))
					elif abberation[4] == '' and abberation[3] != '':
						PatientDiscreetData[element].append(str(abberation[3])+'~'+str(abberation[2]))
					elif abberation[5] != '':
						if critical == '1':
							PatientDiscreetData[element].append(str(abberation[3])+'~'+str(abberation[5]))
						else:
							PatientDiscreetData[element].append(str(abberation[3])+'-MUT')
					else:
						pass
				elif len(abberation) == 7 and abberation[2] == '':
					if abberation[0] != '' and abberation[1] != '':
						PatientDiscreetData[element].append(str(abberation[0])+'~'+str(abberation[1])+'~'+str(abberation[3]))
					elif abberation[0] != '' and abberation[2] != '':
						PatientDiscreetData[element].append(str(abberation[0])+'~'+str(abberation[2])+'~'+str(abberation[3]))
					elif abberation[1] != '':
						PatientDiscreetData[element].append(str(abberation[1])+'~'+str(abberation[3]))
					elif abberation[5] == '' and abberation[4] != '':
						PatientDiscreetData[element].append(str(abberation[4])+'~'+str(abberation[3]))
					elif abberation[6] != '':
						if critical == '1':
							PatientDiscreetData[element].append(str(abberation[4])+'~'+str(abberation[6]))
						else:
							PatientDiscreetData[element].append(str(abberation[4])+'-MUT')
					else:
						pass
				elif len(abberation) == 7 and abberation[1] == '':
					if abberation[0] != '':
						PatientDiscreetData[element].append(str(abberation[0])+'~'+str(abberation[2])+'~'+str(abberation[3]))
					elif abberation[2] != '':
						PatientDiscreetData[element].append(str(abberation[2])+'~'+str(abberation[3]))
					elif abberation[5] == '' and abberation[4] != '':
						PatientDiscreetData[element].append(str(abberation[4])+'~'+str(abberation[3]))
					elif abberation[6] != '':
						if critical == '1':
							PatientDiscreetData[element].append(str(abberation[4])+'~'+str(abberation[6]))
						else:
							PatientDiscreetData[element].append(str(abberation[4])+'-MUT')

				elif len(abberation) == 4 and abberation[1] == '':
					if abberation[0] != '':
						PatientDiscreetData[element].append(str(abberation[0])+'~'+str(abberation[2])+'~'+str(abberation[3]))
					elif abberation[2] != '':
						PatientDiscreetData[element].append(str(abberation[2])+'~'+str(abberation[3]))
#					elif abberation[5] == '' and abberation[4] != '':
#						PatientDiscreetData[element].append(str(abberation[4])+'~'+str(abberation[3]))
#					elif abberation[6] != '':
#						if critical == '1':
#							PatientDiscreetData[element].append(str(abberation[4])+'~'+str(abberation[6]))
#						else:
#							PatientDiscreetData[element].append(str(abberation[4])+'-MUT')
				elif len(abberation) == 3 and abberation[1] != '':
					if 'auto' in abberation:
						PatientDiscreetData[element].append(str(abberation[0])+'~'+str(abberation[1]))

				elif len(abberation) == 3 and abberation[0] != '':
					PatientDiscreetData[element].append(str(abberation[0])+'-MUT')

				elif len(abberation) == 2:
					if abberation[0] != '':
						PatientDiscreetData[element].append(str(abberation[0])+'~'+str(abberation[1]))
					else:
						pass
	for element in PatientDiscreetData:
		for num, abberation in enumerate(PatientDiscreetData[element]):
			try:
				if 'p' in abberation.split('~')[1]:
					PatientDiscreetData[element][num] = abberation.split('~')[0]+'~'+'p'+'~'+abberation.split('~')[2]
				elif 'q' in abberation.split('~')[1]:
					PatientDiscreetData[element][num] = abberation.split('~')[0]+'~'+'q'+'~'+abberation.split('~')[2]
			except:
				pass

	return PatientDiscreetData[patientId]

def createClusterUniv(patientDiscreetData):
	mutaList = []
	mutaCount = {}

	cnvList = []
	cnvCount = {}
	
	for element in patientDiscreetData:
		for mutation in list(set(patientDiscreetData[element])):
			if 'MUT' in mutation:
				if mutation not in mutaList:
					mutaList.append(mutation)
					mutaCount[mutation] = 1
				else:
					mutaCount[mutation] += 1
			else:
				if mutation not in cnvList:
					cnvList.append(mutation)
					cnvCount[mutation] = 1
				else:
					cnvCount[mutation] += 1
		print element, "Completed"
	with open('./freq.txt','w') as f:
		for elem in sorted(cnvCount.items(), key=lambda x:x[1], reverse=True):
			f.write(str(elem)+'\n')

	#Identify top 5 perturbations
	hiFreqMut = sorted(mutaCount.items(), key=lambda x:x[1], reverse=True)[:3]
	hiFreqCnv = sorted(cnvCount.items(), key=lambda x:x[1], reverse=True)[:5]
	features = list([feature[0] for feature in hiFreqMut])+list([feature[0] for feature in hiFreqCnv])

	print hiFreqMut

	print features

	#Creating pseudo-Clusters

	Clusters = {'unc': []}
	for feature in features:
		Clusters[feature] = []

	Comp_Clusters = {}

	Comp_Comp_Clusters = {}

	Comp_Comp_Comp_Clusters = {}


	#Group based on pseudo-Clusters
	coverage = 0
	#tab = []
	for element in patientDiscreetData:
		temp = 0
		for feature in features:
			if feature in patientDiscreetData[element]:
				Clusters[feature].append(element)
				temp += 1
		if temp > 0:
			coverage += 1/len(patientDiscreetData.keys())
		else:
			Clusters['unc'].append(element)
	for element in Clusters:
		print element, len(Clusters[element])

	print "Coverage is:", coverage*100, " %"

	#Merging Clusters L1
	for feat1 in features:
		for feat2 in features:
			if feat1 != feat2:
				common = list(set(Clusters[feat1]).intersection(set(Clusters[feat2])))
				if len(common) > 0:
					Comp_Clusters[str(feat1)+'*'+str(feat2)] = common
					for element in common:
						Clusters[feat1].pop(Clusters[feat1].index(element))
						Clusters[feat2].pop(Clusters[feat2].index(element))
	#L1
	for feat1 in features:
		for feat2 in Comp_Clusters.keys():
			if feat1 not in feat2.split('*'):
				common = list(set(Clusters[feat1]).intersection(set(Comp_Clusters[feat2])))
				if len(common) > 0:
					Comp_Clusters[str(feat1)+'*'+str(feat2)] = common
					for element in common:
						Clusters[feat1].pop(Clusters[feat1].index(element))
						Comp_Clusters[feat2].pop(Comp_Clusters[feat2].index(element))


	#Merging Clustres L3
	for cFeat1 in Comp_Clusters.keys():
		for cFeat2 in Comp_Clusters.keys():
			for comp in cFeat1.split('*'):
				if comp not in cFeat2.split('*'):
					common = list(set(Comp_Clusters[cFeat1]).intersection(Comp_Clusters[cFeat2]))
					if len(common) > 0:
						Comp_Comp_Clusters[str(cFeat1)+'*'+str(cFeat2)] = common
						for element in common:
							Comp_Clusters[cFeat1].pop(Comp_Clusters[cFeat1].index(element))
							Comp_Clusters[cFeat2].pop(Comp_Clusters[cFeat2].index(element))

	#L4
	#for cFeat1 in Comp_Comp_Clusters.keys():
	#	for cFeat2 in Comp_Comp_Clusters.keys():
	#		for comp in cFeat1.split('*'):
	#			if comp not in cFeat2.split('*'):
	#				common = list(set(Comp_Comp_Clusters[cFeat1]).intersection(Comp_Comp_Clusters[cFeat2]))
	#				if len(common) > 0:
	#					Comp_Comp_Comp_Clusters[str(cFeat1)+'*'+str(cFeat2)] = common
	#					for element in common:
	#						Comp_Comp_Clusters[cFeat1].pop(Comp_Comp_Clusters[cFeat1].index(element))
	#						Comp_Comp_Clusters[cFeat2].pop(Comp_Comp_Clusters[cFeat2].index(element))

	

	data_holder = [Comp_Comp_Comp_Clusters, Comp_Comp_Clusters, Comp_Clusters, Clusters]

	return features, data_holder

def writeClusterReports(data, writeLoc):
	if not os.path.exists(os.path.join(writeLoc, 'Reports')):
		os.makedirs(os.path.join(writeLoc, 'Reports'))

	handles = []

	for cComplex in data:
		for element in cComplex.keys():
			if len(cComplex[element]) > 2:
				handles.append(element)
				groupName = str(uuid.uuid4()).split('-')[0]
				with open(os.path.join(writeLoc, 'Reports', groupName), 'w') as f:
					f.write('Genomic-Handle:'+str(element)+'\n')
					for entry in cComplex[element]:
						f.write(str(entry)+'\n')
			elif len(cComplex[element]) > 0:
				with open(os.path.join(writeLoc, 'Reports', 'minigroups'), 'a') as f:
					f.write('Genomic-Handle:'+str(element)+'\n')
					for entry in cComplex[element]:
						f.write(str(entry)+'\n')
					f.write('\n\n')
			
	with open(os.path.join(writeLoc, 'Reports', 'heirarchy_summary'), 'a') as f:
		f.write('\t\t\t\t\t\t\t\t\t\tPopulation\n')
		for key in sorted(handles):
			if len(key.split('*')) == 3:
				f.write('\t'+str(key))
		f.write('\n\n')
		for key in sorted(handles):
			if len(key.split('*')) == 2:		
				f.write('\t\t'+str(key))
		f.write('\n\n')
		for key in sorted(handles):
			if len(key.split('*')) == 1:		
				f.write('\t\t\t'+str(key))
		f.write('\n\n')

if __name__=="__main__":
	script, populationList, dataLoc = sys.argv
	POP_GENOMICS_DATA = parseData(populationList, dataLoc, 0)
	features, data = createClusterUniv(POP_GENOMICS_DATA)
	writeClusterReports(data, dataLoc)












